# Installation

*mcstructure* can be installed/updated with *pip*:

```bash
pip install -U mcstructure
```

