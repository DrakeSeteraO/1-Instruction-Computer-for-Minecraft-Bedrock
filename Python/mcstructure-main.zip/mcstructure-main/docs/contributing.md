# Contributing

Contributions are welcomed. Feel free to
[submit an issue](https://github.com/phoenixr-codes/mcstructure/issues/new/choose)
or help with [already existing issues](https://github.com/phoenixr-codes/mcstructure/issues).
