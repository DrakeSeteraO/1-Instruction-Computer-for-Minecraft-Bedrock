# Changelog

The changelog will be documented as soon as the stable version is released.
