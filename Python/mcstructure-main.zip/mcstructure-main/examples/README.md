# `examples` directory

```text
examples
├── *.py         # example scripts
├── README.md    # This file
├── pack/        # See pack/README.md
└── structures/  # example structures
```

Strcutures beginning with `my_` are generated from a script. Others are
created in Minecraft.
